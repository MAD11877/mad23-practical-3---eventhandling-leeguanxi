package sg.edu.np.mad.week2practical_pleaseworkimdesperate;

public class User {
    String name;
    String description;
    int id;
    boolean followed = false;
}
